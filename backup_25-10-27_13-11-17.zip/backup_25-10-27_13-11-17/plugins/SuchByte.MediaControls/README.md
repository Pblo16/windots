# Media Controls plugin for Macro Deck 2
This plugin can control most of the media players (next, previous, play/pause)

# Features
- ### Next track
- ### Previous track
- ### Play/pause

### This is a plugin for [Macro Deck 2](https://github.com/SuchByte/Macro-Deck), it does NOT function as a standalone app
<img height="64px" src="https://macrodeck.org/images/macro_deck_2_official_plugin.png" />


# Third party licenses
This plugin uses some awesome 3rd party libraries:
- [H.InputSimulator (MS-PL)](https://github.com/HavenDV/H.InputSimulator)
